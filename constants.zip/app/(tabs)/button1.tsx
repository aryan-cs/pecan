import { ThemedText } from "@/components/themed-text";
import React from "react";

export default function Button1Screen() {
  return <ThemedText>Empty screen for Button 1.</ThemedText>;
}
