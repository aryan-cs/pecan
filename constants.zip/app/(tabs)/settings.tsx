import { ThemedText } from '@/components/themed-text';
import { BRAND_DARK_MODE } from '@/constants/theme';
import { useThemeController } from '@/context/theme-context';
import React from 'react';
import { ScrollView, StyleSheet, Switch, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function SettingsScreen() {
  const { toggle, colorScheme } = useThemeController();
  const isDark = colorScheme === 'dark';

  // iOS Settings "Grouped" Background Colors
  const containerColor = isDark ? '#1C1C1E' : '#FFFFFF';
  
  // iOS Green for toggle active state
  const activeSwitchColor = BRAND_DARK_MODE; 

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* <ThemedText type="title" style={styles.header}>Settings</ThemedText> */}

        {/* Settings Group */}
        <View style={styles.section}>
          
          {/* The "Box" around the setting */}
          <View style={[styles.settingBox, { backgroundColor: containerColor }]}>
            <View style={styles.row}>
              <ThemedText style={{ fontSize: 17 }}>Dark Mode</ThemedText>
              <Switch
                trackColor={{ false: '#767577', true: activeSwitchColor }}
                thumbColor={'#f4f3f4'}
                ios_backgroundColor="#3e3e3e"
                onValueChange={toggle}
                value={isDark}
              />
            </View>
          </View>

          {/* Description Text Underneath */}
          <ThemedText style={styles.description}>
            Adjust the appearance of the application to reduce glare and improve readability in low-light environments.
          </ThemedText>
          
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  header: {
    marginBottom: 20,
    paddingHorizontal: 4,
  },
  section: {
    marginBottom: 24,
  },
  settingBox: {
    borderRadius: 10,
    overflow: 'hidden',
    paddingVertical: 14,
    paddingHorizontal: 16,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  description: {
    marginTop: 10,
    paddingHorizontal: 16, // Indent slightly to match iOS description alignment
    fontSize: 13,
    color: '#8E8E93', // Standard iOS Gray for footer text
    lineHeight: 18,
  },
});