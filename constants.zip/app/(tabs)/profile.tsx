import { ThemedText } from '@/components/themed-text';
import React from 'react';

export default function ProfileScreen() {
  return <ThemedText>
    
    Here, you can manage your profile.
    
  </ThemedText>;
}
